<!-- Copyrights -->
<div class="copyrights">
    Copyright © <?php echo e(date('Y')); ?> Smart Tour Guide. All rights reserveds.
 </div>
</div>
<!-- Dashboard / End -->
</div>
<!-- end Container Wrapper -->
<!-- *Scripts* -->
<script src="<?php echo e(asset('assets2/js/jquery-3.2.1.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="<?php echo e(asset('assets2/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets2/js/canvasjs.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets2/js/chart.js')); ?>"></script>
<script src="<?php echo e(asset('assets2/js/counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets2/js/jquery.slicknav.js')); ?>"></script>
<script src="<?php echo e(asset('assets2/js/dashboard-custom.js')); ?>"></script>
<?php /**PATH D:\New folder (2)\resources\views/includes/footer.blade.php ENDPATH**/ ?>