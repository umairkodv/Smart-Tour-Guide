<?php $__env->startSection('title', 'Tourist Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="db-info-wrap">
    <div class="row">
        <!-- Item -->
        <div class="col-xl-3 col-sm-6">
            <div class="db-info-list">
                <div class="dashboard-stat-icon bg-blue">
                    <i class="far fa-chart-bar"></i>
                </div>
                <div class="dashboard-stat-content">
                    <h4>Total Plans</h4>
                    <h5><?php echo e($mytrip_count); ?></h5>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="dashboard-box">
                <h4>My Tour Plans</h4>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Destination</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($trip->destination); ?></td>
                                <td><?php echo e($trip->start_date); ?></td>
                                <td><?php echo e($trip->end_date); ?></td>
                                <td>
                                    <a href="<?php echo e(route('view_trip', ['id'=>$trip->id])); ?>" class="btn btn-primary btn-sm text-white"><i class="fas fa-eye"></i></a>
                                    <a href="<?php echo e(route('edit_trip', ['id'=>$trip->id])); ?>" class="btn btn-primary btn-sm text-white"><i class="fas fa-edit"></i></a>
                                    <a href="#0" class="btn btn-danger btn-sm text-white delete_trip1" data-id="<?php echo e($trip->id); ?>" data-url="<?php echo e(route('delete_trip', ['id'=>$trip->id])); ?>"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
            <div class="col-lg-12">
                <div class="dashboard-box chart-box">
                <h4>Bar Chart</h4>
                <div id="barchart" style="height: 250px; width: 100%;"></div>
                </div>
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.tourist_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder (2)\resources\views/tourist/dashboard.blade.php ENDPATH**/ ?>